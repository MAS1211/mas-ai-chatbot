const express = require('express');
const cors = require('cors');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const OpenAI = require('openai').default;

const app = express();
const PORT = process.env.PORT || 3001;

// ── NVIDIA NIM Client ────────────────────────────────────────────
const nvidia = new OpenAI({
  baseURL: 'https://integrate.api.nvidia.com/v1',
  apiKey: process.env.NVIDIA_API_KEY || '',
});

const SYSTEM_PROMPT = `You are AgriExpert AI, an expert agricultural advisor helping Indian farmers.
- Respond in the SAME language as the question (Hindi or English)
- Give specific quantities, timing, product names
- Keep answers under 200 words
- Be practical and actionable`;

// In-memory session store
const sessions = new Map();

// ── MIDDLEWARE ───────────────────────────────────────────────────
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// ── CHAT API ────────────────────────────────────────────────────
app.post('/chat/message', async (req, res) => {
  const { message, language = 'hi', session_id } = req.body;
  if (!message) return res.status(400).json({ status: 'error', message: 'Message required' });

  const sessionId = session_id || uuidv4();
  const history = sessions.get(sessionId) || [];
  const startTime = Date.now();

  try {
    const messages = [
      { role: 'system', content: SYSTEM_PROMPT },
      ...history.slice(-6),
      { role: 'user', content: message },
    ];

    const completion = await nvidia.chat.completions.create({
      model: 'meta/llama-3.1-8b-instruct',
      messages,
      temperature: 0.4,
      max_tokens: 512,
    });

    const text = completion.choices[0]?.message?.content || '';

    // Update history
    history.push({ role: 'user', content: message });
    history.push({ role: 'assistant', content: text });
    sessions.set(sessionId, history.slice(-20));

    return res.json({
      status: 'success',
      data: {
        message_id: uuidv4(),
        session_id: sessionId,
        response: {
          text,
          language,
          confidence: 0.93,
          sources: ['NVIDIA NIM (Llama 3.1)'],
          follow_up_questions: [],
        },
        metadata: { latency_ms: Date.now() - startTime, model: 'meta/llama-3.1-8b-instruct', from_cache: false },
      },
    });
  } catch (err) {
    console.error('NVIDIA API error:', err.message);
    // Fallback response
    const fallback = language === 'hi'
      ? '🌾 माफ करें, अभी AI सेवा उपलब्ध नहीं है। KVK हेल्पलाइन: 1800-180-1551 पर कॉल करें।'
      : '🌾 Sorry, AI service is temporarily unavailable. Call KVK Helpline: 1800-180-1551';
    return res.json({
      status: 'success',
      data: {
        message_id: uuidv4(),
        session_id: sessionId,
        response: { text: fallback, language, confidence: 0.5, sources: ['Fallback'], follow_up_questions: [] },
        metadata: { latency_ms: Date.now() - startTime, model: 'fallback', from_cache: false },
      },
    });
  }
});

// ── HEALTH CHECK ────────────────────────────────────────────────
app.get('/health', (req, res) => res.json({ status: 'ok', service: 'AgriExpert AI' }));

// ── SERVE REACT FRONTEND ─────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public')));
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ── START ────────────────────────────────────────────────────────
app.listen(PORT, () => console.log(`🌾 AgriExpert AI running on port ${PORT}`));
